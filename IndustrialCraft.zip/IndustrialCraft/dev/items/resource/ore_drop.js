IDRegistry.genItemID("oreCrushedCopper");
Item.createItem("oreCrushedCopper", "Copper Ore", {name: "crushed_ore_copper"});

IDRegistry.genItemID("oreCrushedTin");
Item.createItem("oreCrushedTin", "Tin Ore", {name: "crushed_ore_tin"});

IDRegistry.genItemID("oreCrushedLead");
Item.createItem("oreCrushedLead", "Lead Ore", {name: "crushed_ore_lead"});

IDRegistry.genItemID("uraniumChunk");
Item.createItem("uraniumChunk", "Uranium", {name: "uranium"})
