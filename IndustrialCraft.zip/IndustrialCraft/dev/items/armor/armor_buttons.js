var currentUIscreen;
Callback.addCallback("NativeGuiChanged", function(screenName){
	currentUIscreen = screenName;
});

var UIbuttons = {
	isEnabled: false,
	container: null,
	Window: new UI.Window({
		location: {
			x: 925,
			y: UI.getScreenHeight()/2-150,
			width: 75,
			height: 300
		},
		drawing: [{type: "background", color: 0}],
		elements: {}
	}),
	
	enableButton: function(name){
		this.isEnabled = true;
		buttonMap[name] = true;
	},
	registerButton: function(name, properties){
		buttonContent[name] = properties;
	}
}

var buttonMap = {
	button_nightvision: false,
	button_jump: false,
	button_run: false,
	button_fly: false,
}

var buttonContent = {
	button_nightvision: {
		y: 0,
		type: "button",
		bitmap: "button_nightvision_on",
		bitmap2: "button_nightvision_off",
		scale: 50,
		clicker: {
			onClick: function(){
				if(nightVisionEnabled){
					nightVisionEnabled = false;
					Game.message("§4 Nightvision mode disabled");
				}
				else{
					nightVisionEnabled = true;
					Game.message("§2 Nightvision mode enabled");
				}
			}
		}
	},
	button_fly: {
		y: 1000,
		type: "button",
		bitmap: "button_fly_on",
		bitmap2: "button_fly_off",
		scale: 50
	},
	button_run: {
		y: 2000,
		type: "button",
		bitmap: "button_run_on",
		bitmap2: "button_run_off",
		scale: 50
	},
	button_jump: {
		y: 3000,
		type: "button",
		bitmap: "button_jump_on",
		bitmap2: "button_jump_off",
		scale: 50,
		clicker: {
			onClick: function(){
				var slot = Armor.getForSlot(3);
				var perDamage = ChargeItemRegistry.chargeData[slot.id].perDamage
				if(Item.getMaxDamage(slot.id) - slot.data >= 8 && Math.abs(Player.getVelocity().y + 0.078) < 0.01){
					Player.addVelocity(0, 1.4, 0);
				}
			}
		}
	}
}

function updateUIbuttons(){
	var elements = UIbuttons.Window.content.elements;
	for(var name in buttonMap){
		if(buttonMap[name]){
			if(!elements[name]){
				elements[name] = buttonContent[name];
			}
			elements[name].x = 0;
		}
		else{
			elements[name] = null;
		}
	}
}

Callback.addCallback("tick", function(){
	if(UIbuttons.isEnabled && (currentUIscreen == "hud_screen" || currentUIscreen == "in_game_play_screen")){
		updateUIbuttons();
		if(!UIbuttons.container){
			UIbuttons.container = new UI.Container();
			UIbuttons.container.openAs(UIbuttons.Window);
		}
		if(UIbuttons.container.isElementTouched("button_run")){
			Entity.addEffect(player, MobEffect.movementSpeed, 3, 5);
		}
		if(UIbuttons.container.isElementTouched("button_fly")){
			if(Player.getPosition().y < 255){
				Player.addVelocity(0, 0.13, 0);
			}
		}
	}
	else{
		if(UIbuttons.container){
			UIbuttons.container.close();
			UIbuttons.container = null;
		}
	}
	UIbuttons.isEnabled = false;
	for(var name in buttonMap){
		buttonMap[name] = false;
	}
});

Callback.addCallback("LevelLeft", function(){
	if(UIbuttons.container){
		UIbuttons.container.close();
		UIbuttons.container = null;
	}
});