IDRegistry.genItemID("wrench"); 
Item.createItem("wrench", "Wrench", {
	name: "wrench", 
	meta: 0
	},{
	isTech:false,
	stack:1
	});

Item.setMaxDamage(ItemID.wrench, 250);
 Item.registerUseFunction("wrench", function(coords, item, block){
	if (MachineRegistry.accessMachineAtCoords(coords.x, coords.y, coords.z)){
		World.setBlock(coords.x, coords.y, coords.z, block.id, block.data == coords.side - 2 ? coords.side : block.data);
		Player.setCarriedItem(item.id, ++item.data < 250 ? item.count : 0, item.data);
		var machine = World.getTileEntity(coords.x, coords.y, coords.z)
		if (machine.wrenchDescriptions){
		    var wd = machine.wrenchDescriptions;
		    for (var type in wd){
		        Game.message(wd[type].description + ": " + wd[type].value());
		    }
		}
	}
});

Recipes.addShaped({id: ItemID.wrench, count: 1, data: 0}, [
	"x x",
	"xxx",
	" x "
], ['x', ItemID.plateBronse, -1]);