IDRegistry.genItemID("fluidCellEmpty");
Item.createItem("fluidCellEmpty", "Cell", {name: "cell_empty"});
IDRegistry.genItemID("fluidCellWater");
Item.createItem("fluidCellWater", "Water Cell", {name: "cell_water"});
IDRegistry.genItemID("fluidCellLava");
Item.createItem("fluidCellLava", "Lava Cell", {name: "cell_lava"});

Callback.addCallback("PostLoaded", function(){
	Recipes.addShaped({id: ItemID.fluidCellEmpty, count: 4, data: 0}, [
		" x ",
		"xax",
		" x "
	], ['x', ItemID.casingTin, 0, 'a', 102, 0]);
});