IDRegistry.genItemID("jetpack");
Item.createArmorItem("jetpack", "Jetpack", {name: "armor_jetpack"}, {type: "chestplate", armor: 3, durability: 3000, texture: "armor/jetpack_1.png", isTech: true});
Player.addItemCreativeInv(ItemID.jetpack, 1, 1) ;
ChargeItemRegistry.registerItem(ItemID.jetpack, 30000, 0, true, 10);

Callback.addCallback("PostLoaded", function(){
	Recipes.addShaped({id: ItemID.jetpack, count: 1, data: 3000}, [
		"bcb",
		"bab",
		"d d"
	], ['a', ItemID.storageBatBox, 0, 'b', ItemID.casingIron, 0, 'c', ItemID.circuitAdvanced, 0, "d", 348, 0]);
});