var Tools = {
    registerAsCell: function(id1, id2, liquidData){
        LiquidRegistry.registerItem(liquidData.virtual, {id: id1, data: 0}, {id: id2, data: 0});
        Callback.addCallback("ItemUse", function(coords, item, block){
            if ((liquidData.real) && (block.id == liquidData.real) && (item.id == id1)){
                World.drop(coords.relative.x + 0.5, coords.relative.y + 0.5, coords.relative.z + 0.5, id2, 0);
                Player.decreaseCarriedItem(1);
                nativeSetTile(coords.x, coords.y, coords.z, 0);
            }
        });
    }
}