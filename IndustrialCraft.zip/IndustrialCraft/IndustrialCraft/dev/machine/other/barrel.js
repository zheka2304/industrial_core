IDRegistry.genBlockID("barrel");

Block.createBlock("barrel", [
{name: "Barrel", texture: [["barrel", 1], ["barrel", 1], ["barrel", 0]], inCreative: true}]);

var guiBarrel = new UI.StandartWindow({
	standart: {
		header: {text: {text: "Barrel"}},
		inventory: {standart: true},
		background: {standart: true}
	},
	
	drawing: [
		{type: "bitmap", x: 810, y: 30, bitmap: "liquid_scale_40x8_background", scale: 4}
	],
	
	elements: {
	    "liquidScale": {type: "scale", x: 810, y: 30, direction: 1, value: 0.5, bitmap: "liquid_scale_40x8_empty", overlay: "liquid_scale_40x8_overlay", scale: 4},
		"liquidSlotIn": {type: "slot", x: 700, y: 50, size: 80},
		"liquidSlotOut": {type: "slot", x: 700, y: 150, size: 80},
		"textInfo1": {type: "text", x: 485, y: 150, width: 200, height: 50, text: "test"},
		"textInfo2": {type: "text", x: 485, y: 200, width: 200, height: 50, text: "test2"}
		}
});

TileEntity.registerPrototype(BlockID.barrel, {
    tick: function(){
        if (this.liquidStorage.getLiquidStored()) {
            this.liquidStorage.setLimit(this.liquidStorage)
        }
        var input = this.container.getSlot("liquidSlotIn");
        var output = this.container.getSlot("liquidSlotOut");
        var liquidForStore = "";
        var transfers = {
            empty: LiquidRegistry.getEmptyItem(input.id, input.data),
            full: LiquidRegistry.getFullItem(input.id, input.data, this.liquidStorage.getLiquidStored())
        };
        if (transfers.empty !this.liquidStorage.isFull(this.liquidStorage.getLiquidStored())){
            if ((output.id == transfers.empty.id) && (output.data == transfers.empty.data) && (output.count < 64)){
                output.count += 1;
               input.count -= 1; this.liquidStorage.addLiquid(transfers.empty.liquid, 1);
            }
            else (output.id == 0){
                    output.id == transfers.empty.id;
                    output.data == transfers.empty.data;
                    output.count == 1;
                    input.count -= 1;
                    this.liquidStorage.addLiquid(transfers.empty.liquid, 1);
                } 
            }
        if (transfers.full && !this.liquidStorage.isEmpty(this.liquidStorage.getLiquidStored())){
            if ((output.id == transfers.full.id) && (output.data == transfers.full.data) && (output.count < 64)){
                output.count += 1;
                input.count -= 1;
                this.liquidStorage.getLiquid(this.liquidStorage.getLiquidStored(), 1);
            }
            else (output.id == 0){
                    output.id == transfers.empty.id;
                    output.data == transfers.empty.data;
                    output.count == 1;
                    input.count -= 1;              
                    this.liquidStorage.getLiquid(this.liquidStorage.getLiquidStored, 1);
                } 
            }
         this.container.validateAll();
         if (!this.liquidStorage.isEmpty(this.liquidStorage.getLiquidStored())) this.transfuseLiquid();
    },
    
    getGuiScreen: function(){
        return guiBarrel;
    },
    
    transfuseLiquid: function(){
        var tile = World.getTileEntity(this.x, this.y - 1, this.z);
        if (tile && !tile.liquidStorage.isFull(this.liquidStorage.getLiquidStored())){
            tile.liquidStorage.addLiquid(this.liquidStorage.getLiquid(this.liquidStorage.getLiquidStored()))
        }
    }
});