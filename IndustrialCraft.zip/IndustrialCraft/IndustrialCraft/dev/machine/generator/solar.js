IDRegistry.genBlockID("solarPanel");
Block.createBlock("solarPanel", [
	{name: "Solar Panel", texture: [["machine", 0], ["solar_panel_top", 0], ["machine", 0], ["machine", 0], ["machine", 0], ["machine", 0]], inCreative: true}
]);

Callback.addCallback("PostLoaded", function(){
	Recipes.addShaped({id: BlockID.solarPanel, count: 1, data: 0}, [
		"aaa",
		"xxx",
		"b#b"
	], ['#', BlockID.primalGenerator, -1, 'x', ItemID.dustCoal, 0, 'b', ItemID.circuitBasic, 0, 'a', 20, 0]);
});

MachineRegistry.registerPrototype(BlockID.solarPanel, {
	energyTick: function(){
		if (World.getThreadTime() % 10 == 0 && nativeGetLightLevel(this.x, this.y + 1, this.z) == 15){
			this.web.addEnergy(10);
		}
	}
});


IDRegistry.genBlockID("solarPanelAdvanced");
Block.createBlock("solarPanelAdvanced", [
	{name: "Advanced Solar Panel", texture: [["machine_advanced", 0], ["solar_panel_top", 0], ["machine_advanced", 0], ["machine_advanced", 0], ["machine_advanced", 0], ["machine_advanced", 0]], inCreative: true}
]);

Callback.addCallback("PostLoaded", function(){
	Recipes.addShaped({id: BlockID.solarPanelAdvanced, count: 1, data: 0}, [
		"aaa",
		"aaa",
		"a#a"
	], ['#', BlockID.machineBlockAdvanced, -1, 'a', BlockID.solarPanel, 0]);
});

MachineRegistry.registerPrototype(BlockID.solarPanelAdvanced, {
	energyTick: function(){
		if (World.getThreadTime() % 10 == 0){
			this.web.addEnergy((nativeGetLightLevel(this.x, this.y + 1, this.z) + 1) * 10);
		}
	}
});
